#include <iostream>

using namespace std;

int main()
{
    int x;
    cout<<"Soal 1 [Abrar Halim Novidra- 1301164383]"<<endl;
    cout << "Masukan angka : " ;
    cin >>x;

    if (x % 2 == 0){
        cout<<x << " adalah bilangan genap";
    }else{
        cout<<x << " adalah bilangan ganjil";
    }
    return 0;
}
